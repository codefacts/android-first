package com.imslbd.android_first.util;

import android.support.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * Created by shahadat on 1/6/16.
 */
public class JsonArrayListAdapter<T> implements List<T> {
    private final JSONArray array;

    public JsonArrayListAdapter(JSONArray array) {
        this.array = array;
    }

    @Override
    public void add(int location, T object) {
        try {
            array.put(location, object);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean add(T object) {
        array.put(object);
        return true;
    }

    @Override
    public boolean addAll(int location, Collection<? extends T> collection) {
        int i = 0;
        for (T c : collection) {
            try {
                array.put(location + i++, c);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends T> collection) {
        for (T c : collection) {
            array.put(c);
        }
        return true;
    }

    @Override
    public void clear() {
    }

    @Override
    public boolean contains(Object object) {
        for (int i = 0; i < array.length(); i++) {
            if (array.opt(i).equals(object)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> collection) {
        for (Object object : collection) {
            for (int i = 0; i < array.length(); i++) {
                if (array.opt(i).equals(object)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public T get(int location) {
        return (T) array.opt(location);
    }

    @Override
    public int indexOf(Object object) {
        for (int i = 0; i < array.length(); i++) {
            if (object.equals(array.opt(i))) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        return array.length() <= 0;
    }

    @NonNull
    @Override
    public Iterator<T> iterator() {
        ;
    }

    @Override
    public int lastIndexOf(Object object) {
        return 0;
    }

    @Override
    public ListIterator<T> listIterator() {
        return null;
    }

    @NonNull
    @Override
    public ListIterator<T> listIterator(int location) {
        return null;
    }

    @Override
    public T remove(int location) {
        return null;
    }

    @Override
    public boolean remove(Object object) {
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        return false;
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        return false;
    }

    @Override
    public T set(int location, T object) {
        return null;
    }

    @Override
    public int size() {
        return 0;
    }

    @NonNull
    @Override
    public List<T> subList(int start, int end) {
        return null;
    }

    @NonNull
    @Override
    public Object[] toArray() {
        return new Object[0];
    }

    @NonNull
    @Override
    public <T1> T1[] toArray(T1[] array) {
        return null;
    }
}
