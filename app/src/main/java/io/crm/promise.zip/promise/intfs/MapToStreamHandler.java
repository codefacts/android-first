package io.crm.promise.intfs;

import io.crm.intfs.FunctionAsync;

/**
 * Created by someone on 17/11/2015.
 */
public interface MapToStreamHandler<T, R> extends FunctionAsync<T, R>, Invokable {
}
