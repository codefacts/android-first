package io.crm.promise.intfs;

import io.crm.intfs.PredicateUnchecked;

/**
 * Created by someone on 08/11/2015.
 */
public interface FilterHandler<T> extends PredicateUnchecked<T>, Invokable {
}
