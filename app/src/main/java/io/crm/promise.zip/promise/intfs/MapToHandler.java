package io.crm.promise.intfs;

import io.crm.intfs.FunctionUnchecked;

/**
 * Created by someone on 16/10/2015.
 */
public interface MapToHandler<T, R> extends FunctionUnchecked<T, R>, Invokable {
}
