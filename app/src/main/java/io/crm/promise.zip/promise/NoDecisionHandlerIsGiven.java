package io.crm.promise;

/**
 * Created by someone on 09/11/2015.
 */
public class NoDecisionHandlerIsGiven extends RuntimeException {
    public NoDecisionHandlerIsGiven(String s) {
        super(s);
    }
}
