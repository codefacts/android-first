package io.crm.promise.intfs;

import io.crm.intfs.FunctionUnchecked;

/**
 * Created by someone on 08/11/2015.
 */
public interface ThenDecideHandler<T> extends FunctionUnchecked<T, String>, Invokable {
}
